/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package calculadora;

public class Calculadora {
    
    public int Somar(int a, int b){ // Calculo de Soma
        return a + b;
    }
    
    public int Subtrair(int a, int b){ // Calculo de Subtração
        return a - b;
    }
    
    public int Multiplicar(int a, int b){ // Calculo de Multiplicação
        return a * b;
    }
    
    public double Dividir(int a, int b){ // Calculo de Divisão
        return a / b;
    }
}
